#ifndef __CONFIG_H 
#define __CONFIG_H

//*** <<< Use Configuration Wizard in Context Menu >>> ***

/*
// <h> Test Configuration
//   <o0> Scenario under test  <0=> Ideal <1=> Typical <2=> Optimized 
//   <o1> Number Of Packets To Send <50-1000>
//   <o2> Frame Size <60-1514> 
// </h>
*/
#define SCENARIO				0
#define NUMBER_FRAMES			50									  
#define FRAMESIZE				1514


#endif /* end __CONFIG_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/
