
FatFs is a generic FAT file system module for small embedded systems. 
The FatFs is written in compliance with ANSI C and completely separated from 
the disk I/O layer. Therefore it is independent of hardware architecture. 
It can be incorporated into low cost microcontrollers, such as AVR, 8051, PIC, 
ARM, Z80 and etc..., without any change. 

This project port FatFs (0.08a) to NXP Cortex-M3 LPC17xx MCUs.

Code used in this project:
- FatFs(0.08a), terminal input/output, Diskio functions: ChaN
- SSP FIFO: Martin Thomas
- LPC17xx SD/SPI/RTC/UART drivers: NXP

The code is tested on Keil MCB1768 board with 2/4/8GB MicroSD(HC) cards.

System settings:
 - Clock Settings:
   - XTAL  =  12 MHz
   - PLL0  = 400 MHz
   - CCLK  = 100 MHz